"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2330], {
        7309: function(e, s, i) {
            var l = i(7437),
                c = i(7138);
            i(2265), s.Z = () => (0, l.jsx)("footer", {
                className: "footer-section",
                children: (0, l.jsxs)("div", {
                    className: "container",
                    children: [(0, l.jsx)("div", {
                        className: "footer-menu-wrap",
                        children: (0, l.jsxs)("div", {
                            className: "row gy-5",
                            children: [(0, l.jsx)("div", {
                                className: "col-lg-4 col-md-6 col-sm-8",
                                children: (0, l.jsxs)("div", {
                                    className: "footer-content-area",
                                    children: [(0, l.jsx)(c.default, {
                                        href: "",
                                        className: "footer-logo",
                                        children: (0, l.jsx)("img", {
                                            src: "/assets/img/footer-logo.svg",
                                            alt: ""
                                        })
                                    }), (0, l.jsx)("p", {
                                        children: "An Art Action Company typically operates in the space of live art, performance, and social practice, often combining elements of activism and community engagement."
                                    }), (0, l.jsxs)("ul", {
                                        className: "social-list",
                                        children: [(0, l.jsx)("li", {
                                            children: (0, l.jsxs)("a", {
                                                href: "https://www.facebook.com/",
                                                children: [(0, l.jsx)("i", {
                                                    className: "bi bi-facebook"
                                                }), (0, l.jsx)("span", {
                                                    children: "Facebook"
                                                })]
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsxs)("a", {
                                                href: "https://www.instagram.com/",
                                                children: [(0, l.jsx)("i", {
                                                    className: "bi bi-instagram"
                                                }), (0, l.jsx)("span", {
                                                    children: "Instagram"
                                                })]
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsxs)("a", {
                                                href: "https://www.linkedin.com/",
                                                children: [(0, l.jsx)("i", {
                                                    className: "bi bi-linkedin"
                                                }), (0, l.jsx)("span", {
                                                    children: "LinkedIn"
                                                })]
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsxs)("a", {
                                                href: "https://twitter.com/",
                                                children: [(0, l.jsx)("i", {
                                                    className: "bi bi-twitter-x"
                                                }), (0, l.jsx)("span", {
                                                    children: "Twitter"
                                                })]
                                            })
                                        })]
                                    })]
                                })
                            }), (0, l.jsx)("div", {
                                className: "col-lg-2 col-md-3 col-sm-4 d-flex justify-content-lg-end justify-content-md-center justify-content-sm-end",
                                children: (0, l.jsxs)("div", {
                                    className: "footer-widget",
                                    children: [(0, l.jsx)("div", {
                                        className: "widget-title",
                                        children: (0, l.jsx)("h5", {
                                            children: "Menu"
                                        })
                                    }), (0, l.jsxs)("ul", {
                                        className: "widget-list",
                                        children: [(0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "",
                                                children: "Artists Portfolio"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)("a", {
                                                href: "/general-art-details",
                                                children: "Art Catalog"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)("a", {
                                                href: "#",
                                                children: "Departments"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/contact",
                                                children: "Contact"
                                            })
                                        })]
                                    })]
                                })
                            }), (0, l.jsx)("div", {
                                className: "col-lg-2 col-md-3 col-sm-5 d-flex justify-content-md-end",
                                children: (0, l.jsxs)("div", {
                                    className: "footer-widget",
                                    children: [(0, l.jsx)("div", {
                                        className: "widget-title",
                                        children: (0, l.jsx)("h5", {
                                            children: "Resources"
                                        })
                                    }), (0, l.jsxs)("ul", {
                                        className: "widget-list",
                                        children: [(0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/auction",
                                                children: "Blog"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/about",
                                                children: "About us"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/how-to-bid",
                                                children: "How to bid"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/how-to-sell",
                                                children: "How to sell"
                                            })
                                        }), (0, l.jsx)("li", {
                                            children: (0, l.jsx)(c.default, {
                                                href: "/faq",
                                                children: "F.A.Q"
                                            })
                                        })]
                                    })]
                                })
                            }), (0, l.jsx)("div", {
                                className: "col-md-4 col-sm-7 d-flex justify-content-lg-end justify-content-md-center justify-content-sm-end",
                                children: (0, l.jsxs)("div", {
                                    className: "newsletter-and-payment-area",
                                    children: [(0, l.jsx)("h4", {
                                        children: "For Exclusive Art Updates Join Our Newsletter!"
                                    }), (0, l.jsx)("form", {
                                        children: (0, l.jsxs)("div", {
                                            className: "form-inner",
                                            children: [(0, l.jsx)("input", {
                                                type: "email",
                                                placeholder: "Email Address"
                                            }), (0, l.jsx)("button", {
                                                type: "submit",
                                                children: (0, l.jsx)("i", {
                                                    className: "bi bi-arrow-right"
                                                })
                                            })]
                                        })
                                    }), (0, l.jsxs)("div", {
                                        className: "payment-area",
                                        children: [(0, l.jsx)("h6", {
                                            children: "Secured Payment Gateways"
                                        }), (0, l.jsxs)("ul", {
                                            className: "payment-options",
                                            children: [(0, l.jsx)("li", {
                                                children: (0, l.jsx)("img", {
                                                    src: "/assets/img/home1/icon/visa.svg",
                                                    alt: ""
                                                })
                                            }), (0, l.jsx)("li", {
                                                children: (0, l.jsx)("img", {
                                                    src: "/assets/img/home1/icon/master-card.svg",
                                                    alt: ""
                                                })
                                            }), (0, l.jsx)("li", {
                                                children: (0, l.jsx)("img", {
                                                    src: "/assets/img/home1/icon/american-express.svg",
                                                    alt: ""
                                                })
                                            }), (0, l.jsx)("li", {
                                                children: (0, l.jsx)("img", {
                                                    src: "/assets/img/home1/icon/maestro.svg",
                                                    alt: ""
                                                })
                                            })]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }), (0, l.jsxs)("div", {
                        className: "footer-bottom",
                        children: [(0, l.jsx)("div", {
                            className: "copyright-area",
                            children: (0, l.jsxs)("p", {
                                children: ["\xa9Copyright 2025 ", (0, l.jsx)(c.default, {
                                    href: "/",
                                    children: "Artmart"
                                }), " | Design By ", (0, l.jsx)("a", {
                                    href: "https://www.egenslab.com/",
                                    children: "bansi dhadaniya"
                                })]
                            })
                        }), (0, l.jsx)("div", {
                            className: "footer-bottom-right",
                            children: (0, l.jsxs)("ul", {
                                children: [(0, l.jsx)("li", {
                                    children: (0, l.jsx)("a", {
                                        href: "#",
                                        children: "Support Center"
                                    })
                                }), (0, l.jsx)("li", {
                                    children: (0, l.jsx)(c.default, {
                                        href: "/terms-condition",
                                        children: "Terms & Conditions"
                                    })
                                }), (0, l.jsx)("li", {
                                    children: (0, l.jsx)(c.default, {
                                        href: "/privacy-policy",
                                        children: "Privacy Policy"
                                    })
                                })]
                            })
                        })]
                    })]
                })
            })
        },
        5470: function(e, s, i) {
            i.d(s, {
                default: function() {
                    return t
                }
            });
            var l = i(7437),
                c = i(2265),
                n = function(e) {
                    let s = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        [i, l] = (0, c.useState)(s),
                        [n, t] = (0, c.useState)(null),
                        r = () => {
                            l(!1)
                        };
                    return {
                        isOpen: i,
                        selectedOption: n,
                        options: e,
                        openDropdown: () => {
                            l(!0)
                        },
                        closeDropdown: r,
                        toggleDropdown: () => {
                            l(!i)
                        },
                        selectOption: e => {
                            t(e), r()
                        }
                    }
                },
                t = e => {
                    let {
                        options: s,
                        placeholder: i,
                        open: t,
                        customClass: r,
                        onSelect: a
                    } = e, {
                        isOpen: d,
                        selectedOption: o,
                        openDropdown: h,
                        closeDropdown: m,
                        toggleDropdown: j,
                        selectOption: x
                    } = n(s, t), f = (0, c.useRef)(null), u = e => {
                        f.current && !f.current.contains(e.target) && m()
                    };
                    (0, c.useEffect)(() => (d && document.addEventListener("click", u), () => {
                        document.removeEventListener("click", u)
                    }), [d]);
                    let g = e => {
                            x(e), h(), a && a(e)
                        },
                        p = "nice-select ".concat(r || "", " ").concat(d ? "open" : "");
                    return (0, l.jsxs)("div", {
                        className: p,
                        tabIndex: "0",
                        onClick: j,
                        ref: f,
                        children: [(0, l.jsx)("span", {
                            className: "current",
                            children: o || i
                        }), (0, l.jsx)("ul", {
                            className: "list",
                            children: s.map((e, s) => (0, l.jsx)("li", {
                                className: "option".concat(o === e ? " selected focus" : ""),
                                "data-value": s,
                                onClick: () => g(e),
                                children: e
                            }, s))
                        })]
                    })
                }
        }
    }
]);