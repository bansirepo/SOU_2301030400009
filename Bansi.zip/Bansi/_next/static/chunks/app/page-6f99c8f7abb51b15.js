(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1931], {
        9769: function(s, e, i) {
            Promise.resolve().then(i.t.bind(i, 231, 23)), Promise.resolve().then(i.bind(i, 2618)), Promise.resolve().then(i.bind(i, 1050)), Promise.resolve().then(i.bind(i, 2596)), Promise.resolve().then(i.bind(i, 6256)), Promise.resolve().then(i.bind(i, 8932)), Promise.resolve().then(i.bind(i, 9862)), Promise.resolve().then(i.bind(i, 9301)), Promise.resolve().then(i.bind(i, 8241))
        },
        2618: function(s, e, i) {
            "use strict";
            i.r(e), i.d(e, {
                default: function() {
                    return d
                }
            });
            var a = i(7437),
                l = i(2265),
                c = i(5844),
                n = function() {
                    arguments.length > 0 && void 0 !== arguments[0] && arguments[0], arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    let [s, e] = (0, l.useState)(!1), i = (0, l.useCallback)(() => e(!0), []), n = (0, l.useCallback)(() => e(!1), []);
                    return {
                        openModal: i,
                        Modal: () => (0, a.jsx)(c.Z, {
                            channel: "youtube",
                            isOpen: s,
                            videoId: "r4KpWiK08vM",
                            animationSpeed: 350,
                            onClose: n
                        })
                    }
                },
                r = i(7138),
                d = s => {
                    let {
                        sectionGap: e
                    } = s, {
                        Modal: i,
                        openModal: l
                    } = n();
                    return (0, a.jsxs)("div", {
                        className: "home1-about-section mb-130",
                        children: [(0, a.jsxs)("div", {
                            className: "container",
                            children: [(0, a.jsx)("div", {
                                className: "about-top-area mb-50",
                                children: (0, a.jsxs)("div", {
                                    className: "row g-4 align-items-center justify-content-between",
                                    children: [(0, a.jsx)("div", {
                                        className: "col-lg-8 wow animate fadeInDown",
                                        "data-wow-delay": "200ms",
                                        "data-wow-duration": "1500ms",
                                        children: (0, a.jsxs)("div", {
                                            className: "about-title-area",
                                            children: [(0, a.jsxs)("div", {
                                                className: "section-title",
                                                children: [(0, a.jsx)("span", {
                                                    children: "Building Trust Since 2005"
                                                }), (0, a.jsx)("h2", {
                                                    children: "Experts in Construction Your Excellence."
                                                })]
                                            }), (0, a.jsxs)("div", {
                                                className: "video-and-content",
                                                children: [(0, a.jsx)("a", {
                                                    "data-fancybox": "video-player",
                                                    onClick: l,
                                                    className: "video-area",
                                                    children: (0, a.jsxs)("div", {
                                                        className: "icon",
                                                        children: [(0, a.jsxs)("svg", {
                                                            className: "video-circle",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            xmlnsXlink: "http://www.w3.org/1999/xlink",
                                                            x: "0px",
                                                            y: "0px",
                                                            width: "77px",
                                                            viewBox: "0 0 206 206",
                                                            style: {
                                                                enableBackground: "new 0 0 206 206"
                                                            },
                                                            xmlSpace: "preserve",
                                                            children: [(0, a.jsx)("circle", {
                                                                className: "circle",
                                                                strokeMiterlimit: 10,
                                                                cx: 103,
                                                                cy: 103,
                                                                r: 100
                                                            }), (0, a.jsx)("path", {
                                                                className: "circle-half top-half",
                                                                strokeWidth: 4,
                                                                strokeMiterlimit: 10,
                                                                d: "M16.4,53C44,5.2,105.2-11.2,153,16.4s64.2,88.8,36.6,136.6"
                                                            }), (0, a.jsx)("path", {
                                                                className: "circle-half bottom-half",
                                                                strokeWidth: 4,
                                                                strokeMiterlimit: 10,
                                                                d: "M189.6,153C162,200.8,100.8,217.2,53,189.6S-11.2,100.8,16.4,53"
                                                            })]
                                                        }), (0, a.jsx)("svg", {
                                                            className: "play-icon",
                                                            width: 23,
                                                            height: 28,
                                                            viewBox: "0 0 23 28",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: (0, a.jsx)("path", {
                                                                d: "M22.8424 14.2559C22.8424 13.4843 22.4449 12.7737 21.7784 12.3539L3.78608 1.03446C3.05833 0.577358 2.17083 0.543963 1.40902 0.947257C0.649591 1.35033 0.195312 2.09429 0.195312 2.93663V25.5738C0.195312 26.4162 0.649555 27.1599 1.41018 27.5632C1.76475 27.7501 2.14507 27.8431 2.52543 27.8431C2.96275 27.8431 3.39718 27.7197 3.78584 27.476L21.7782 16.1583C22.4449 15.7383 22.8424 15.0277 22.8424 14.2561V14.2559ZM21.1289 15.177L3.13659 26.4947C2.78345 26.7165 2.35329 26.7315 1.98441 26.5376C1.61553 26.3424 1.39473 25.9822 1.39473 25.5736V2.93642C1.39473 2.52778 1.61553 2.16621 1.98441 1.97237C2.15681 1.88239 2.34185 1.83669 2.52569 1.83669C2.73791 1.83669 2.9487 1.8963 3.13685 2.0155L21.1292 13.335C21.4568 13.5414 21.6447 13.8781 21.6447 14.2575C21.6444 14.6356 21.4565 14.9707 21.1289 15.177Z"
                                                            })
                                                        })]
                                                    })
                                                }), (0, a.jsx)("div", {
                                                    className: "content",
                                                    children: (0, a.jsx)("p", {
                                                        children: "Sed nisl eros, condimentum nec risus sit amet, finibus conguese.Fusen fringilla est libero, sed tempus urna feugiat eu. Curabitur eu feugiat ligu Suspendisse nectoraba porttitor velit go this week and more about."
                                                    })
                                                })]
                                            })]
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "col-xl-2 col-lg-3 d-flex justify-content-lg-end",
                                        children: (0, a.jsxs)(r.default, {
                                            href: "/about",
                                            className: "about-btn btn_wrapper",
                                            children: [(0, a.jsx)("div", {
                                                className: "bg",
                                                children: (0, a.jsxs)("svg", {
                                                    width: 170,
                                                    height: 170,
                                                    viewBox: "0 0 170 170",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [(0, a.jsx)("path", {
                                                        d: "M77.3692 2.27213C82.1102 -0.382126 87.8898 -0.382126 92.6308 2.27213C95.8749 4.08835 99.6604 4.68792 103.307 3.96307C108.636 2.90377 114.133 4.68978 117.822 8.67916C120.346 11.409 123.761 13.149 127.453 13.5865C132.848 14.2258 137.524 17.623 139.8 22.557C141.357 25.9332 144.067 28.6434 147.443 30.2003C152.377 32.4757 155.774 37.1516 156.414 42.5472C156.851 46.2393 158.591 49.6543 161.321 52.1784C165.31 55.8671 167.096 61.3638 166.037 66.693C165.312 70.3396 165.912 74.1251 167.728 77.3692C170.382 82.1102 170.382 87.8898 167.728 92.6308C165.912 95.8749 165.312 99.6604 166.037 103.307C167.096 108.636 165.31 114.133 161.321 117.822C158.591 120.346 156.851 123.761 156.414 127.453C155.774 132.848 152.377 137.524 147.443 139.8C144.067 141.357 141.357 144.067 139.8 147.443C137.524 152.377 132.848 155.774 127.453 156.414C123.761 156.851 120.346 158.591 117.822 161.321C114.133 165.31 108.636 167.096 103.307 166.037C99.6604 165.312 95.8749 165.912 92.6308 167.728C87.8898 170.382 82.1102 170.382 77.3692 167.728C74.1251 165.912 70.3396 165.312 66.693 166.037C61.3638 167.096 55.8671 165.31 52.1784 161.321C49.6543 158.591 46.2393 156.851 42.5472 156.414C37.1516 155.774 32.4757 152.377 30.2003 147.443C28.6434 144.067 25.9332 141.357 22.557 139.8C17.623 137.524 14.2258 132.848 13.5865 127.453C13.149 123.761 11.409 120.346 8.67916 117.822C4.68978 114.133 2.90377 108.636 3.96307 103.307C4.68792 99.6604 4.08835 95.8749 2.27213 92.6308C-0.382126 87.8898 -0.382126 82.1102 2.27213 77.3692C4.08835 74.1251 4.68792 70.3396 3.96307 66.693C2.90377 61.3638 4.68977 55.8671 8.67916 52.1784C11.409 49.6543 13.149 46.2393 13.5865 42.5472C14.2258 37.1516 17.623 32.4757 22.557 30.2003C25.9332 28.6434 28.6434 25.9332 30.2003 22.557C32.4757 17.623 37.1516 14.2258 42.5472 13.5865C46.2393 13.149 49.6543 11.409 52.1784 8.67916C55.8671 4.68977 61.3638 2.90377 66.693 3.96307C70.3396 4.68792 74.1251 4.08835 77.3692 2.27213Z"
                                                    }), (0, a.jsx)("path", {
                                                        d: "M77.6135 2.70841C82.2027 0.139114 87.7973 0.139114 92.3865 2.70841C95.7345 4.58277 99.6412 5.20153 103.404 4.45348C108.563 3.42808 113.884 5.15692 117.455 9.01861C120.059 11.8358 123.584 13.6315 127.394 14.083C132.617 14.7019 137.143 17.9903 139.346 22.7664C140.952 26.2507 143.749 29.0476 147.234 30.6544C152.01 32.8569 155.298 37.3831 155.917 42.6061C156.368 46.4163 158.164 49.9406 160.981 52.5455C164.843 56.1161 166.572 61.437 165.547 66.5955C164.798 70.3588 165.417 74.2655 167.292 77.6135C169.861 82.2027 169.861 87.7973 167.292 92.3865C165.417 95.7345 164.798 99.6412 165.547 103.404C166.572 108.563 164.843 113.884 160.981 117.455C158.164 120.059 156.368 123.584 155.917 127.394C155.298 132.617 152.01 137.143 147.234 139.346C143.749 140.952 140.952 143.749 139.346 147.234C137.143 152.01 132.617 155.298 127.394 155.917C123.584 156.368 120.059 158.164 117.455 160.981C113.884 164.843 108.563 166.572 103.404 165.547C99.6412 164.798 95.7345 165.417 92.3865 167.292C87.7973 169.861 82.2027 169.861 77.6135 167.292C74.2655 165.417 70.3588 164.798 66.5955 165.547C61.437 166.572 56.1161 164.843 52.5455 160.981C49.9406 158.164 46.4163 156.368 42.6061 155.917C37.3831 155.298 32.8569 152.01 30.6544 147.234C29.0476 143.749 26.2507 140.952 22.7664 139.346C17.9903 137.143 14.7019 132.617 14.083 127.394C13.6315 123.584 11.8358 120.059 9.01861 117.455C5.15692 113.884 3.42808 108.563 4.45348 103.404C5.20153 99.6412 4.58277 95.7345 2.70841 92.3865C0.139114 87.7973 0.139114 82.2027 2.70841 77.6135C4.58277 74.2655 5.20153 70.3588 4.45348 66.5955C3.42808 61.437 5.15692 56.1161 9.01861 52.5455C11.8358 49.9406 13.6315 46.4163 14.083 42.606C14.7019 37.3831 17.9903 32.8569 22.7664 30.6544C26.2507 29.0476 29.0476 26.2507 30.6544 22.7664C32.8569 17.9903 37.3831 14.7019 42.606 14.083C46.4163 13.6315 49.9406 11.8358 52.5455 9.01861C56.1161 5.15692 61.437 3.42808 66.5955 4.45348C70.3588 5.20153 74.2655 4.58277 77.6135 2.70841Z",
                                                        strokeOpacity: "0.1"
                                                    })]
                                                })
                                            }), (0, a.jsxs)("div", {
                                                className: "primary-btn",
                                                children: ["About Us More", (0, a.jsx)("svg", {
                                                    viewBox: "0 0 13 20",
                                                    children: (0, a.jsx)("polyline", {
                                                        points: "0.5 19.5 3 19.5 12.5 10 3 0.5"
                                                    })
                                                })]
                                            })]
                                        })
                                    })]
                                })
                            }), (0, a.jsxs)("div", {
                                className: "row align-items-center",
                                children: [(0, a.jsx)("div", {
                                    className: "col-lg-5",
                                    children: (0, a.jsx)("div", {
                                        className: "about-content",
                                        children: (0, a.jsxs)("ul", {
                                            children: [(0, a.jsxs)("li", {
                                                children: [(0, a.jsx)("h5", {
                                                    children: "Who we are"
                                                }), (0, a.jsx)("p", {
                                                    children: "Sed nisl eros, condimentum nec risussit amet finibus cons sem fusce. Advantage of thes limited-time offers & start."
                                                })]
                                            }), (0, a.jsxs)("li", {
                                                children: [(0, a.jsx)("h5", {
                                                    children: "Our Mission"
                                                }), (0, a.jsx)("p", {
                                                    children: "Sed nisl eros, condimentum nec risussit amet finibus cons sem fusce. Advantage of thes limited-time offers & start."
                                                })]
                                            }), (0, a.jsxs)("li", {
                                                children: [(0, a.jsx)("h5", {
                                                    children: "Core value"
                                                }), (0, a.jsx)("p", {
                                                    children: "Sed nisl eros, condimentum nec risussit amet finibus cons sem fusce. Advantage of thes limited-time offers & start."
                                                })]
                                            })]
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "col-lg-7 d-lg-block d-none",
                                    children: (0, a.jsx)("div", {
                                        className: "about-img magnetic-item",
                                        children: (0, a.jsx)("img", {
                                            src: "assets/img/home1/about-img.jpg",
                                            alt: ""
                                        })
                                    })
                                })]
                            })]
                        }), (0, a.jsx)(i, {})]
                    })
                }
        },
        2596: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985),
                r = i(7138);
            n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let s = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    effect: "fade",
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    pagination: {
                        el: ".swiper-pagination1",
                        clickable: !0
                    }
                }), []);
                return (0, a.jsx)(a.Fragment, {
                    children: (0, a.jsxs)("div", {
                        className: "home1-banner-section mb-120",
                        children: [(0, a.jsx)(c.tq, { ...s,
                            className: "swiper home1-banner-slider",
                            children: (0, a.jsxs)("div", {
                                className: "swiper-wrapper",
                                children: [(0, a.jsx)(c.o5, {
                                    className: "swiper-slide",
                                    children: (0, a.jsx)("div", {
                                        className: "banner-bg",
                                        style: {
                                            backgroundImage: "linear-gradient(180deg, rgba(0, 0, 0, 0.46) 0%, rgba(0, 0, 0, 0.46) 100%), url(assets/img/home1/home1-banner-bg1.jpg)"
                                        }
                                    })
                                }), (0, a.jsx)(c.o5, {
                                    className: "swiper-slide",
                                    children: (0, a.jsx)("div", {
                                        className: "banner-bg",
                                        style: {
                                            backgroundImage: "linear-gradient(180deg, rgba(0, 0, 0, 0.46) 0%, rgba(0, 0, 0, 0.46) 100%), url(assets/img/home1/home1-banner-bg2.jpg)"
                                        }
                                    })
                                }), (0, a.jsx)(c.o5, {
                                    className: "swiper-slide",
                                    children: (0, a.jsx)("div", {
                                        className: "banner-bg",
                                        style: {
                                            backgroundImage: "linear-gradient(180deg, rgba(0, 0, 0, 0.46) 0%, rgba(0, 0, 0, 0.46) 100%), url(assets/img/home1/home1-banner-bg3.jpg)"
                                        }
                                    })
                                })]
                            })
                        }), (0, a.jsx)("div", {
                            className: "banner-wrapper",
                            children: (0, a.jsx)("div", {
                                className: "container",
                                children: (0, a.jsx)("div", {
                                    className: "row",
                                    children: (0, a.jsx)("div", {
                                        className: "col-xxl-7 col-lg-8",
                                        children: (0, a.jsxs)("div", {
                                            className: "banner-content",
                                            children: [(0, a.jsx)("h1", {
                                                children: "Art That Speaks To Your Soul "
                                            }), (0, a.jsx)("p", {
                                                children: "Unlock a world of imagination with our curated collection of original artworks. From bold abstracts to serene landscapes, discover pieces that inspire, captivate."
                                            }), (0, a.jsxs)(r.default, {
                                                href: "/auction",
                                                className: "primary-btn1 btn-hover",
                                                children: [(0, a.jsx)("span", {
                                                    children: "Explore Now"
                                                }), (0, a.jsx)("strong", {
                                                    style: {
                                                        top: "48px",
                                                        left: "69.5px"
                                                    }
                                                })]
                                            })]
                                        })
                                    })
                                })
                            })
                        }), (0, a.jsx)("div", {
                            className: "pagination-area",
                            children: (0, a.jsx)("div", {
                                className: "swiper-pagination1"
                            })
                        })]
                    })
                })
            }
        },
        6256: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985),
                r = i(7138);
            n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let s = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    spaceBetween: 25,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    navigation: {
                        nextEl: ".article-slider-next",
                        prevEl: ".article-slider-prev"
                    },
                    breakpoints: {
                        280: {
                            slidesPerView: 1
                        },
                        386: {
                            slidesPerView: 1
                        },
                        576: {
                            slidesPerView: 1
                        },
                        768: {
                            slidesPerView: 2
                        },
                        992: {
                            slidesPerView: 3
                        },
                        1200: {
                            slidesPerView: 4,
                            spaceBetween: 15
                        },
                        1400: {
                            slidesPerView: 4
                        }
                    }
                }), []);
                return (0, a.jsx)("div", {
                    className: "home1-article-section mb-120",
                    children: (0, a.jsxs)("div", {
                        className: "container",
                        children: [(0, a.jsxs)("div", {
                            className: "row mb-50 align-items-center justify-content-between flex-wrap gap-3 wow animate fadeInDown",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "col-lg-8 col-md-9",
                                children: (0, a.jsxs)("div", {
                                    className: "section-title",
                                    children: [(0, a.jsx)("h3", {
                                        children: "Latest Article"
                                    }), (0, a.jsx)("p", {
                                        children: "Our Article is your go-to resource for all things related to art, auctions, and the vibrant community of artists and collectors."
                                    })]
                                })
                            }), (0, a.jsx)("div", {
                                className: "col-lg-2 col-md-2 d-flex justify-content-md-end",
                                children: (0, a.jsx)(r.default, {
                                    href: "/article",
                                    className: "view-all-btn",
                                    children: "View All"
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "article-slider-wrap wow animate fadeInUp",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "row",
                                children: (0, a.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, a.jsx)(c.tq, { ...s,
                                        className: "swiper home1-article-slider",
                                        children: (0, a.jsxs)("div", {
                                            className: "swiper-wrapper",
                                            children: [(0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img1.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "31 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "2 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "The Last Light of a Forgotten City Breaking"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img2.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "25 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "6 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "Art as Therapy: Creativity for Mental Wellness"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img3.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "18 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "3 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "How Art Reflects and Influences Modern Culture"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img4.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "15 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "3 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "Insights into the Creative Process of Artists"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img5.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "12 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "4 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "Spotlighting Emerging Artists Making Their Mark"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img6.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "22 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "2 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "Understanding Color Psychology in Artistic"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "article-card",
                                                    children: [(0, a.jsx)(r.default, {
                                                        href: "/article/details",
                                                        className: "article-img",
                                                        children: (0, a.jsx)("img", {
                                                            src: "assets/img/home1/article-img7.jpg",
                                                            alt: ""
                                                        })
                                                    }), (0, a.jsx)("div", {
                                                        className: "article-content-wrap",
                                                        children: (0, a.jsxs)("div", {
                                                            className: "article-content",
                                                            children: [(0, a.jsxs)("div", {
                                                                className: "blog-meta",
                                                                children: [(0, a.jsx)(r.default, {
                                                                    href: "/article",
                                                                    className: "blog-date",
                                                                    children: "24 July, 2024"
                                                                }), (0, a.jsx)("div", {
                                                                    className: "blog-comment",
                                                                    children: (0, a.jsx)("span", {
                                                                        children: "5 Comments"
                                                                    })
                                                                })]
                                                            }), (0, a.jsx)("h6", {
                                                                children: (0, a.jsx)(r.default, {
                                                                    href: "/auction/details",
                                                                    children: "The Impact of Technology on Today’s Art"
                                                                })
                                                            }), (0, a.jsx)(r.default, {
                                                                href: "/article/details",
                                                                className: "read-btn",
                                                                children: "Read Article"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "slider-btn-grp",
                                children: [(0, a.jsx)("div", {
                                    className: "slider-btn article-slider-prev",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M0.735295 8.27932L10 16L4.10428 8.27932L10 0.558823L0.735295 8.27932Z"
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "slider-btn article-slider-next",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M9.26471 7.72068L0 0L5.89572 7.72068L0 15.4412L9.26471 7.72068Z"
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        8932: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985),
                r = i(7138),
                d = i(5984);
            n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let {
                    days: s,
                    hours: e,
                    minutes: i,
                    seconds: n
                } = (0, d.useCountdownTimer)("2025-10-23"), t = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    spaceBetween: 25,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    navigation: {
                        nextEl: ".auction-slider-next",
                        prevEl: ".auction-slider-prev"
                    },
                    breakpoints: {
                        280: {
                            slidesPerView: 1
                        },
                        386: {
                            slidesPerView: 1
                        },
                        576: {
                            slidesPerView: 1
                        },
                        768: {
                            slidesPerView: 2
                        },
                        992: {
                            slidesPerView: 3
                        },
                        1200: {
                            slidesPerView: 4,
                            spaceBetween: 15
                        },
                        1400: {
                            slidesPerView: 4
                        }
                    }
                }), []);
                return (0, a.jsx)("div", {
                    className: "home1-auction-slider-section mb-120",
                    children: (0, a.jsxs)("div", {
                        className: "container",
                        children: [(0, a.jsxs)("div", {
                            className: "row mb-50 align-items-center justify-content-between flex-wrap gap-3 wow animate fadeInDown",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "col-lg-8 col-md-9",
                                children: (0, a.jsxs)("div", {
                                    className: "section-title",
                                    children: [(0, a.jsx)("h3", {
                                        children: "Streaming Auctions"
                                    }), (0, a.jsx)("p", {
                                        children: "Join us for an exhilarating live auction experience where art meets excitement. "
                                    })]
                                })
                            }), (0, a.jsx)("div", {
                                className: "col-lg-2 col-md-2 d-flex justify-content-md-end",
                                children: (0, a.jsx)(r.default, {
                                    href: "/auction",
                                    className: "view-all-btn",
                                    children: "View All"
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "auction-slider-wrap wow animate fadeInUp",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "row",
                                children: (0, a.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, a.jsx)(c.tq, { ...t,
                                        className: "swiper home1-auction-slider",
                                        children: (0, a.jsxs)("div", {
                                            className: "swiper-wrapper",
                                            children: [(0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img1.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "More than just art—it's a feeling"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img2.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-18 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "A masterpiece that invites you to dream"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Pablo Picasso"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$218.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img3.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-25 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "A work of art that sparks your imagination"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Yayoi Kusama"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$358.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img4.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-25 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Whispers of Solitude of a Forgotten City"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$310.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img5.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-12 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "The Last Light Echoes of My Youth"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Gustav Klimt"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$284.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img6.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-05 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "A brushstroke of serenity in a chaotic world"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Henri Matisse"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$284.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/auction-img7.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-18 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Dancing Colors on a Summer Breeze"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Joan Mir\xf3"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$256.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "slider-btn-grp",
                                children: [(0, a.jsx)("div", {
                                    className: "slider-btn auction-slider-prev",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M0.735295 8.27932L10 16L4.10428 8.27932L10 0.558823L0.735295 8.27932Z"
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "slider-btn auction-slider-next",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M9.26471 7.72068L0 0L5.89572 7.72068L0 15.4412L9.26471 7.72068Z"
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        9862: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985),
                r = i(7138);
            n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let s = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    spaceBetween: 25,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    navigation: {
                        nextEl: ".generat-art-slider-next",
                        prevEl: ".generat-art-slider-prev"
                    },
                    breakpoints: {
                        280: {
                            slidesPerView: 1
                        },
                        386: {
                            slidesPerView: 1
                        },
                        576: {
                            slidesPerView: 1
                        },
                        768: {
                            slidesPerView: 2
                        },
                        992: {
                            slidesPerView: 3
                        },
                        1200: {
                            slidesPerView: 4,
                            spaceBetween: 15
                        },
                        1400: {
                            slidesPerView: 4
                        }
                    }
                }), []);
                return (0, a.jsx)("div", {
                    className: "home1-general-art-slider-section mb-120",
                    children: (0, a.jsxs)("div", {
                        className: "container",
                        children: [(0, a.jsxs)("div", {
                            className: "row mb-60 align-items-center justify-content-between flex-wrap gap-3 wow animate fadeInDown",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "col-lg-8 col-md-9",
                                children: (0, a.jsxs)("div", {
                                    className: "section-title",
                                    children: [(0, a.jsx)("h3", {
                                        children: "General Artwork"
                                    }), (0, a.jsx)("p", {
                                        children: "Join us for an exhilarating live auction experience where art meets excitement."
                                    })]
                                })
                            }), (0, a.jsx)("div", {
                                className: "col-lg-2 col-md-2 d-flex justify-content-md-end",
                                children: (0, a.jsx)(r.default, {
                                    href: "/general-art-grid",
                                    className: "view-all-btn",
                                    children: "View All"
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "general-art-slider-wrap wow animate fadeInUp",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "row",
                                children: (0, a.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, a.jsx)(c.tq, { ...s,
                                        className: "swiper home1-generat-art-slider",
                                        children: (0, a.jsxs)("div", {
                                            className: "swiper-wrapper",
                                            children: [(0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img1.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Dancing Colors on a Summer Breeze"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Joan Mir\xf3"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img2.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "The Last Light Echoes of My Youth"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$270.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img3.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Whispers of Solitude of a Forgotten City"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$320.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img4.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "sold-out",
                                                                children: "Sold Out"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Sighs of Isolation from a Lost City"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Pablo Picasso"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$380.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover disabled",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img5.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Bright Colors on the Summer Wind"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Joan Mir\xf3"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$250.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img6.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "The Final Rays of Light from My Childhood"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$230.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)("div", {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card general-art",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/general-art-img7.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "The Shining Day Remnants of My Early Years"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Yayoi Kusama"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$230.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/general-art-details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Buy Now"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "slider-btn-grp",
                                children: [(0, a.jsx)("div", {
                                    className: "slider-btn generat-art-slider-prev",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M0.735295 8.27932L10 16L4.10428 8.27932L10 0.558823L0.735295 8.27932Z"
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "slider-btn generat-art-slider-next",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M9.26471 7.72068L0 0L5.89572 7.72068L0 15.4412L9.26471 7.72068Z"
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        9301: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985);
            i(7138), n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let s = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    spaceBetween: 25,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    navigation: {
                        nextEl: ".testimonial-slider-next",
                        prevEl: ".testimonial-slider-prev"
                    },
                    breakpoints: {
                        280: {
                            slidesPerView: 1
                        },
                        386: {
                            slidesPerView: 1
                        },
                        576: {
                            slidesPerView: 1
                        },
                        768: {
                            slidesPerView: 2
                        },
                        992: {
                            slidesPerView: 2
                        },
                        1200: {
                            slidesPerView: 3,
                            spaceBetween: 15
                        },
                        1400: {
                            slidesPerView: 3
                        }
                    }
                }), []);
                return (0, a.jsxs)("div", {
                    className: "home1-testimonial-section mb-120",
                    children: [(0, a.jsx)("div", {
                        className: "container",
                        children: (0, a.jsx)("div", {
                            className: "row mb-50 wow animate fadeInDown",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: (0, a.jsx)("div", {
                                className: "col-lg-12",
                                children: (0, a.jsxs)("div", {
                                    className: "section-title",
                                    children: [(0, a.jsx)("h3", {
                                        children: "Client Acknowledgment"
                                    }), (0, a.jsx)("p", {
                                        children: "Join us for an exhilarating live auction experience where art meets excitement. "
                                    })]
                                })
                            })
                        })
                    }), (0, a.jsx)("div", {
                        className: "container-fluid",
                        children: (0, a.jsxs)("div", {
                            className: "testimonial-slider-wrap",
                            children: [(0, a.jsx)("div", {
                                className: "row",
                                children: (0, a.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, a.jsx)(c.tq, { ...s,
                                        className: "swiper home1-testimonial-slider",
                                        children: (0, a.jsxs)("div", {
                                            className: "swiper-wrapper",
                                            children: [(0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Great Auction Product!"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img1.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "Miss. Abelam"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Artist"
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Jan 20, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "10.30 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Fantastic Bidding Item!"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img2.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "Mr. Harry"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Art Teacher "
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Jul 10, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "12.25 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Excellent Auction Item!"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img3.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "Luke Jane"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Art Critic"
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Aug 23, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "12.25 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Wonderful Bidding Deal"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img4.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "Mr. Abid"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Exhibition Manager"
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Jan 20, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "10.30 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Excellent Item for Auctions!"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img5.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "Mrs. Lucas"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Art Teacher"
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Jul 10, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "12.25 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "testimonial-card",
                                                    children: [(0, a.jsx)("h5", {
                                                        children: "Amazing Bidding Items!"
                                                    }), (0, a.jsx)("p", {
                                                        children: '"I purchased a beautiful painting from this site, and the quality is incredible. The buying process was seamless, and the delivery was prompt. Highly recommend for anyone looking to buy unique art."'
                                                    }), (0, a.jsxs)("svg", {
                                                        className: "quote",
                                                        width: 54,
                                                        height: 49,
                                                        viewBox: "0 0 54 49",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: [(0, a.jsx)("path", {
                                                            d: "M36.1221 48.6582C36.8815 48.4756 40.3092 46.6602 41.7647 45.6719C43.6526 44.3936 44.7178 43.5234 46.3104 41.9014C51.4678 36.6807 53.419 31.1914 53.8936 20.5781C53.9674 19.0527 53.9991 14.7881 53.978 10.1045C53.9463 2.76758 53.9358 2.17676 53.7565 1.82227C53.5034 1.31738 53.0076 0.801758 52.4803 0.511719L52.0479 0.275391L42.9248 0.275392C35.4682 0.275392 33.728 0.307619 33.3905 0.425783C32.8737 0.6084 32.2198 1.20996 31.9244 1.76856L31.6924 2.20899L31.6608 11.3828C31.6291 21.4697 31.6186 21.2441 32.2725 22.0498C32.4412 22.2647 32.8315 22.5654 33.1373 22.7158L33.6858 22.9951L38.0416 22.9951L42.3975 22.9951L42.3975 23.7793C42.3975 25.498 41.9862 27.915 41.3955 29.7197C40.0561 33.8018 37.7252 36.3799 33.3272 38.625C32.4729 39.0654 31.6397 39.5596 31.4498 39.7637C30.9647 40.2686 30.7643 40.8916 30.817 41.708C30.8592 42.3096 31.0069 42.6963 32.1143 45.0488C33.4116 47.8096 33.6541 48.1855 34.4241 48.5078C34.8987 48.7119 35.637 48.7764 36.1221 48.6582Z"
                                                        }), (0, a.jsx)("path", {
                                                            d: "M6.11524 48.3145C13.2133 45.1563 18.6238 39.7852 21.018 33.5225C21.7035 31.7393 22.3152 29.0215 22.6633 26.2178C23.1063 22.7051 23.1484 21.3838 23.1484 11.6084C23.1484 2.5957 23.1379 2.1875 22.948 1.80078C22.6949 1.27441 22.2414 0.8125 21.6824 0.511719L21.25 0.275391L12.0742 0.275392C2.97227 0.275392 2.89844 0.275392 2.42383 0.500978C1.8543 0.769533 1.43242 1.18848 1.11602 1.7793C0.894533 2.20899 0.894533 2.23047 0.862893 11.3828C0.831253 21.4697 0.820707 21.2441 1.47461 22.0498C1.64336 22.2647 2.0336 22.5654 2.33946 22.7158L2.88789 22.9951L7.29649 22.9951C11.5891 22.9951 11.7051 22.9951 11.7051 23.1992C11.7051 24.0049 11.4309 26.3789 11.2199 27.4531C10.893 29.1074 10.5449 30.1709 9.85938 31.6426C8.40391 34.7578 6.18907 36.8525 2.42383 38.7002C0.483207 39.6455 0.0613324 40.1504 0.0507868 41.5254C0.0507868 42.2666 0.0718802 42.3096 1.26368 44.834C1.92813 46.2305 2.61368 47.5625 2.78243 47.7773C3.53126 48.7012 4.78633 48.9053 6.11524 48.3145Z"
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "testimonial-bottom-area",
                                                        children: [(0, a.jsxs)("div", {
                                                            className: "author-area",
                                                            children: [(0, a.jsx)("div", {
                                                                className: "author-img",
                                                                children: (0, a.jsx)("img", {
                                                                    src: "assets/img/home1/testimonial-author-img6.png",
                                                                    alt: ""
                                                                })
                                                            }), (0, a.jsxs)("div", {
                                                                className: "author-content",
                                                                children: [(0, a.jsx)("h5", {
                                                                    children: "John Doe"
                                                                }), (0, a.jsx)("span", {
                                                                    children: "Artist"
                                                                })]
                                                            })]
                                                        }), (0, a.jsxs)("div", {
                                                            className: "date-and-time-area",
                                                            children: [(0, a.jsx)("strong", {
                                                                children: "Aug 23, 2024"
                                                            }), (0, a.jsx)("span", {
                                                                children: "12.25 PM"
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "slider-btn-grp",
                                children: [(0, a.jsx)("div", {
                                    className: "slider-btn testimonial-slider-prev",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M0.735295 8.27932L10 16L4.10428 8.27932L10 0.558823L0.735295 8.27932Z"
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "slider-btn testimonial-slider-next",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M9.26471 7.72068L0 0L5.89572 7.72068L0 15.4412L9.26471 7.72068Z"
                                        })
                                    })
                                })]
                            })]
                        })
                    })]
                })
            }
        },
        8241: function(s, e, i) {
            "use strict";
            var a = i(7437),
                l = i(2265),
                c = i(2334),
                n = i(9985),
                r = i(7138),
                d = i(5984);
            n.ZP.use([n.pt, n.xW, n.W_, n.tl]), e.default = () => {
                let {
                    days: s,
                    hours: e,
                    minutes: i,
                    seconds: n
                } = (0, d.useCountdownTimer)("2025-10-23"), t = (0, l.useMemo)(() => ({
                    slidesPerView: "auto",
                    speed: 1500,
                    spaceBetween: 25,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: !1
                    },
                    navigation: {
                        nextEl: ".upcoming-auction-slider-next",
                        prevEl: ".upcoming-auction-slider-prev"
                    },
                    breakpoints: {
                        280: {
                            slidesPerView: 1
                        },
                        386: {
                            slidesPerView: 1
                        },
                        576: {
                            slidesPerView: 1
                        },
                        768: {
                            slidesPerView: 2
                        },
                        992: {
                            slidesPerView: 3
                        },
                        1200: {
                            slidesPerView: 4,
                            spaceBetween: 15
                        },
                        1400: {
                            slidesPerView: 4
                        }
                    }
                }), []);
                return (0, a.jsx)("div", {
                    className: "home1-upcoming-auction-slider-section mb-120",
                    children: (0, a.jsxs)("div", {
                        className: "container",
                        children: [(0, a.jsxs)("div", {
                            className: "row mb-50 align-items-center justify-content-between flex-wrap gap-3 wow animate fadeInDown",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "col-lg-8 col-md-9",
                                children: (0, a.jsxs)("div", {
                                    className: "section-title",
                                    children: [(0, a.jsx)("h3", {
                                        children: "Upcoming Auctions"
                                    }), (0, a.jsx)("p", {
                                        children: "Join us for an exhilarating live auction experience where art meets excitement. "
                                    })]
                                })
                            }), (0, a.jsx)("div", {
                                className: "col-lg-2 col-md-2 d-flex justify-content-md-end",
                                children: (0, a.jsx)(r.default, {
                                    href: "/upcoming-auction-grid",
                                    className: "view-all-btn",
                                    children: "View All"
                                })
                            })]
                        }), (0, a.jsxs)("div", {
                            className: "upcoming-auction-slider-wrap wow animate fadeInUp",
                            "data-wow-delay": "200ms",
                            "data-wow-duration": "1500ms",
                            children: [(0, a.jsx)("div", {
                                className: "row",
                                children: (0, a.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, a.jsx)(c.tq, { ...t,
                                        className: "swiper home1-upcoming-auction-slider",
                                        children: (0, a.jsxs)("div", {
                                            className: "swiper-wrapper",
                                            children: [(0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img1.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "A moment captured in color and form"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img2.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-18 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "Whispers of the Forest Secrets by the Wind"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Pablo Picasso"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$218.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img3.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-25 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "The Last Light Echoes of My Youth "
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Yayoi Kusama"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$358.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img4.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-25 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "Dancing Colors on a Summer Breeze"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$310.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img5.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-12 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "The Final Rays of Light from My Childhood"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Gustav Klimt"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$284.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img6.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-10-05 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "A brushstroke of serenity in a chaotic world"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Henri Matisse"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$284.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, a.jsx)(c.o5, {
                                                className: "swiper-slide",
                                                children: (0, a.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, a.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, a.jsx)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "card-img",
                                                            children: (0, a.jsx)("img", {
                                                                src: "assets/img/home1/upcoming-auction-img7.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, a.jsx)("span", {
                                                                className: "upcoming",
                                                                children: "UpComing"
                                                            })
                                                        }), (0, a.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, a.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, a.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, a.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, a.jsxs)("ul", {
                                                                "data-countdown": "2025-09-18 12:00:00",
                                                                children: [(0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [s, "D"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [e, "H"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [i, "M"]
                                                                }), (0, a.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, a.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [n, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, a.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, a.jsx)("h6", {
                                                            children: (0, a.jsx)(r.default, {
                                                                href: "/auction/details2",
                                                                children: "Bright Colors on the Summer Wind"
                                                            })
                                                        }), (0, a.jsxs)("ul", {
                                                            children: [(0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Joan Mir\xf3"]
                                                            }), (0, a.jsxs)("li", {
                                                                children: [(0, a.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$256.00"]
                                                            })]
                                                        }), (0, a.jsxs)(r.default, {
                                                            href: "/auction/details2",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, a.jsx)("span", {
                                                                children: "Notify Me"
                                                            }), (0, a.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    })
                                })
                            }), (0, a.jsxs)("div", {
                                className: "slider-btn-grp",
                                children: [(0, a.jsx)("div", {
                                    className: "slider-btn upcoming-auction-slider-prev",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M0.735295 8.27932L10 16L4.10428 8.27932L10 0.558823L0.735295 8.27932Z"
                                        })
                                    })
                                }), (0, a.jsx)("div", {
                                    className: "slider-btn upcoming-auction-slider-next",
                                    children: (0, a.jsx)("svg", {
                                        width: 10,
                                        height: 16,
                                        viewBox: "0 0 10 16",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: (0, a.jsx)("path", {
                                            d: "M9.26471 7.72068L0 0L5.89572 7.72068L0 15.4412L9.26471 7.72068Z"
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                })
            }
        }
    },
    function(s) {
        s.O(0, [2291, 2334, 5844, 1050, 2971, 7023, 1744], function() {
            return s(s.s = 9769)
        }), _N_E = s.O()
    }
]);