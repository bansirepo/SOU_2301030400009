(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3785], {
        8741: function(s, e, a) {
            Promise.resolve().then(a.bind(a, 5800))
        },
        5800: function(s, e, a) {
            "use strict";
            a.r(e);
            var i = a(7437),
                l = a(7309),
                c = a(1050),
                n = a(5470),
                d = a(5984),
                r = a(7138),
                t = a(5533),
                h = a(8294),
                x = a(2265);
            e.default = () => {
                let [s, e] = (0, x.useState)([20, 37]), {
                    days: a,
                    hours: o,
                    minutes: j,
                    seconds: m
                } = (0, d.useCountdownTimer)("2025-10-23"), [u, N] = (0, x.useState)("column-3"), p = s => {
                    N(s)
                };
                return (0, i.jsxs)("div", {
                    children: [(0, i.jsx)(c.default, {}), (0, i.jsx)("div", {
                        className: "breadcrumb-section2",
                        style: {
                            backgroundImage: "linear-gradient(180deg, rgba(0, 0, 0, 0.28), rgba(0, 0, 0, 0.28)), url(/assets/img/inner-page/breadcrumb-image2.jpg)"
                        },
                        children: (0, i.jsxs)("div", {
                            className: "container",
                            children: [(0, i.jsx)("div", {
                                className: "row",
                                children: (0, i.jsx)("div", {
                                    className: "col-lg-12 d-flex",
                                    children: (0, i.jsx)("div", {
                                        className: "top-content style-2",
                                        children: (0, i.jsxs)("ul", {
                                            children: [(0, i.jsx)("li", {
                                                children: (0, i.jsx)(r.default, {
                                                    href: "/",
                                                    children: (0, i.jsx)("svg", {
                                                        width: 12,
                                                        height: 12,
                                                        viewBox: "0 0 12 12",
                                                        fill: "none",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        children: (0, i.jsx)("path", {
                                                            d: "M1.125 5.99955L5.602 1.52205C5.822 1.30255 6.178 1.30255 6.3975 1.52205L10.875 5.99955M2.25 4.87455V9.93705C2.25 10.2475 2.502 10.4995 2.8125 10.4995H4.875V8.06205C4.875 7.75155 5.127 7.49955 5.4375 7.49955H6.5625C6.873 7.49955 7.125 7.75155 7.125 8.06205V10.4995H9.1875C9.498 10.4995 9.75 10.2475 9.75 9.93705V4.87455M4.125 10.4995H8.25",
                                                            stroke: "white",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round"
                                                        })
                                                    })
                                                })
                                            }), (0, i.jsx)("li", {
                                                children: "Art Catalog"
                                            })]
                                        })
                                    })
                                })
                            }), (0, i.jsx)("div", {
                                className: "row",
                                children: (0, i.jsx)("div", {
                                    className: "col-lg-12",
                                    children: (0, i.jsxs)("div", {
                                        className: "breadcrumb-content",
                                        children: [(0, i.jsx)("h1", {
                                            children: "Art Catalog"
                                        }), (0, i.jsx)("p", {
                                            children: "An art catalog is a curated assembly of artworks gathered by an individual, institution, or group, often reflecting the collector's interests, tastes, or a specific theme."
                                        })]
                                    })
                                })
                            })]
                        })
                    }), (0, i.jsx)("div", {
                        className: "auction-card-sidebar-section pt-120 mb-120",
                        children: (0, i.jsx)("div", {
                            className: "container",
                            children: (0, i.jsxs)("div", {
                                className: "row gy-5",
                                children: [(0, i.jsx)("div", {
                                    className: "col-xl-3 order-xl-1 order-2",
                                    children: (0, i.jsxs)("div", {
                                        className: "sidebar-area",
                                        children: [(0, i.jsx)("div", {
                                            className: "single-widgets widget_search mb-50",
                                            children: (0, i.jsx)("form", {
                                                children: (0, i.jsxs)("div", {
                                                    className: "wp-block-search__inside-wrapper ",
                                                    children: [(0, i.jsx)("input", {
                                                        type: "search",
                                                        id: "wp-block-search__input-1",
                                                        className: "wp-block-search__input",
                                                        name: "s",
                                                        placeholder: "Search Artist",
                                                        required: !0
                                                    }), (0, i.jsx)("button", {
                                                        type: "submit",
                                                        className: "wp-block-search__button",
                                                        children: (0, i.jsx)("svg", {
                                                            width: 16,
                                                            height: 16,
                                                            viewBox: "0 0 16 16",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: (0, i.jsx)("path", {
                                                                d: "M11.7425 10.3418C12.7107 9.0205 13.1444 7.38236 12.9567 5.75508C12.769 4.1278 11.9739 2.63139 10.7303 1.56522C9.48666 0.49905 7.88635 -0.0582469 6.2495 0.0048239C4.61265 0.0678947 3.05997 0.746681 1.90209 1.90538C0.744221 3.06409 0.0665459 4.61725 0.00464636 6.25415C-0.0572531 7.89104 0.501188 9.49095 1.56825 10.7338C2.63531 11.9766 4.13229 12.7707 5.7597 12.9572C7.38711 13.1438 9.02494 12.7089 10.3455 11.7397H10.3445C10.3745 11.7797 10.4065 11.8177 10.4425 11.8547L14.2924 15.7046C14.4799 15.8922 14.7342 15.9977 14.9995 15.9977C15.2647 15.9978 15.5192 15.8926 15.7068 15.7051C15.8944 15.5176 15.9999 15.2632 16 14.9979C16.0001 14.7327 15.8948 14.4782 15.7073 14.2906L11.8575 10.4408C11.8217 10.4046 11.7833 10.3711 11.7425 10.3408V10.3418ZM12.0004 6.4979C12.0004 7.22015 11.8582 7.93532 11.5818 8.60258C11.3054 9.26985 10.9003 9.87614 10.3896 10.3868C9.87889 10.8975 9.2726 11.3027 8.60533 11.5791C7.93807 11.8554 7.2229 11.9977 6.50065 11.9977C5.77841 11.9977 5.06324 11.8554 4.39597 11.5791C3.72871 11.3027 3.12242 10.8975 2.61171 10.3868C2.10101 9.87614 1.6959 9.26985 1.41951 8.60258C1.14312 7.93532 1.00086 7.22015 1.00086 6.4979C1.00086 5.03927 1.5803 3.64037 2.61171 2.60896C3.64312 1.57755 5.04202 0.99811 6.50065 0.99811C7.95929 0.99811 9.35818 1.57755 10.3896 2.60896C11.421 3.64037 12.0004 5.03927 12.0004 6.4979Z"
                                                            })
                                                        })
                                                    })]
                                                })
                                            })
                                        }), (0, i.jsxs)("div", {
                                            className: "single-widgets mb-50",
                                            children: [(0, i.jsx)("div", {
                                                className: "widget-title",
                                                children: (0, i.jsx)("h5", {
                                                    children: "Shop Catalog"
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "checkbox-container",
                                                children: (0, i.jsxs)("ul", {
                                                    children: [(0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Auction Art"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "General Art"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Upcoming Auction Art"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            })]
                                        }), (0, i.jsxs)("div", {
                                            className: "single-widgets mb-50",
                                            children: [(0, i.jsx)("div", {
                                                className: "widget-title",
                                                children: (0, i.jsx)("h5", {
                                                    children: "Artist Name"
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "checkbox-container",
                                                children: (0, i.jsxs)("ul", {
                                                    children: [(0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Frida Kahlo "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Pablo Picasso "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Leonardo da Vinci"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Gustav Klimt"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Yayoi Kusama"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "button-area",
                                                children: (0, i.jsx)("a", {
                                                    href: "#",
                                                    children: "See More"
                                                })
                                            })]
                                        }), (0, i.jsxs)("div", {
                                            className: "single-widgets mb-50",
                                            children: [(0, i.jsx)("div", {
                                                className: "widget-title",
                                                children: (0, i.jsx)("h5", {
                                                    children: "Category"
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "checkbox-container",
                                                children: (0, i.jsxs)("ul", {
                                                    children: [(0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Painting "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Sculpture "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Print"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Natura"
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Street Art"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "button-area",
                                                children: (0, i.jsx)("a", {
                                                    href: "#",
                                                    children: "See More"
                                                })
                                            })]
                                        }), (0, i.jsxs)("div", {
                                            className: "single-widgets mb-50",
                                            children: [(0, i.jsx)("div", {
                                                className: "widget-title",
                                                children: (0, i.jsx)("h5", {
                                                    children: "Department"
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "checkbox-container",
                                                children: (0, i.jsxs)("ul", {
                                                    children: [(0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Post War "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Contemporary Art "
                                                            })]
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsxs)("label", {
                                                            className: "containerss",
                                                            children: [(0, i.jsx)("input", {
                                                                type: "checkbox"
                                                            }), (0, i.jsx)("span", {
                                                                className: "checkmark"
                                                            }), (0, i.jsx)("span", {
                                                                children: "Print and Multiples"
                                                            })]
                                                        })
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "button-area",
                                                children: (0, i.jsx)("a", {
                                                    href: "#",
                                                    children: "See More"
                                                })
                                            })]
                                        }), (0, i.jsxs)("div", {
                                            className: "single-widgets mb-30",
                                            children: [(0, i.jsx)("div", {
                                                className: "widget-title",
                                                children: (0, i.jsx)("h5", {
                                                    children: "Price Filter"
                                                })
                                            }), (0, i.jsxs)(t.Z, {
                                                sx: {
                                                    xs: "100%",
                                                    sm: "50%",
                                                    md: "33.33%",
                                                    lg: "25%",
                                                    xl: "20%"
                                                },
                                                children: [(0, i.jsx)(h.ZP, {
                                                    getAriaLabel: () => "Temperature range",
                                                    value: s,
                                                    sx: {
                                                        color: "#222222"
                                                    },
                                                    onChange: (s, a) => {
                                                        e(a)
                                                    },
                                                    valueLabelDisplay: "auto",
                                                    getAriaValueText: function(s) {
                                                        return "".concat(s)
                                                    }
                                                }), (0, i.jsx)("div", {
                                                    className: "range-wrap",
                                                    children: (0, i.jsxs)("div", {
                                                        className: "slider-labels",
                                                        children: [(0, i.jsx)("div", {
                                                            className: "caption",
                                                            children: (0, i.jsxs)("span", {
                                                                id: "slider-range-value1",
                                                                children: ["$", s[0]]
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "caption",
                                                            children: (0, i.jsxs)("span", {
                                                                id: "slider-range-value2",
                                                                children: ["$", s[1]]
                                                            })
                                                        })]
                                                    })
                                                })]
                                            })]
                                        })]
                                    })
                                }), (0, i.jsxs)("div", {
                                    className: "col-xl-9 order-xl-2 order-1",
                                    children: [(0, i.jsx)("div", {
                                        className: "row",
                                        children: (0, i.jsx)("div", {
                                            className: "col-lg-12 mb-30",
                                            children: (0, i.jsxs)("div", {
                                                className: "auction-card-top-area",
                                                children: [(0, i.jsx)("div", {
                                                    className: "left-content",
                                                    children: (0, i.jsxs)("h6", {
                                                        children: ["Showing ", (0, i.jsx)("span", {
                                                            children: "09"
                                                        }), " of ", (0, i.jsx)("span", {
                                                            children: "12"
                                                        }), " results"]
                                                    })
                                                }), (0, i.jsxs)("div", {
                                                    className: "right-content",
                                                    children: [(0, i.jsx)("div", {
                                                        className: "category-area d-lg-flex d-none active",
                                                        children: (0, i.jsx)(n.default, {
                                                            options: ["latest", "Best selling", "Price Low to high", "Price high to low"],
                                                            placeholder: "sorting"
                                                        })
                                                    }), (0, i.jsxs)("ul", {
                                                        className: "size-icon grid-view d-lg-flex d-none",
                                                        children: [(0, i.jsx)("li", {
                                                            className: "column-2" === u ? "active" : "",
                                                            onClick: () => p("column-2"),
                                                            children: (0, i.jsx)("svg", {
                                                                width: 7,
                                                                height: 14,
                                                                viewBox: "0 0 7 14",
                                                                fill: "none",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M0.75 13.1875L0.749999 0.8125M5.8125 13.1875L5.8125 0.8125",
                                                                    stroke: "#A0A0A0",
                                                                    strokeWidth: "1.5",
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("li", {
                                                            className: "column-3" === u ? "active" : "",
                                                            onClick: () => p("column-3"),
                                                            children: (0, i.jsx)("svg", {
                                                                width: 10,
                                                                height: 14,
                                                                viewBox: "0 0 10 14",
                                                                fill: "none",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M1.0625 13.1875L1.0625 0.8125M5 13.1875L5 0.8125M8.9375 13.1875L8.9375 0.8125",
                                                                    stroke: "white",
                                                                    strokeWidth: "1.5",
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round"
                                                                })
                                                            })
                                                        })]
                                                    })]
                                                })]
                                            })
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "list-grid-product-wrap ".concat("column-2" === u ? "column-2-wrapper" : "column-3-wrapper"),
                                        children: (0, i.jsxs)("div", {
                                            className: "row gy-4",
                                            children: [(0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "200ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img3.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Frida Kahlo Cat love’s"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "400ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img2.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "A masterpiece that invites you to dream"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "600ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img1.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "More than just art—it's a feeling"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "800ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img5.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "The Last Light Echoes of My Youth "
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "800ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img4.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Whispers of Solitude of a Forgotten City"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "600ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img6.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "A brushstroke of serenity in a chaotic world"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "400ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/home1/auction-img7.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Dancing Colors on a Summer Breeze"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Joan Mir\xf3"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "200ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/inner-page/auction-img8.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "An invitation to explore the unseen"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Andy Warhol"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            }), (0, i.jsx)("div", {
                                                className: "col-lg-4 col-md-6 item wow animate fadeInDown",
                                                "data-wow-delay": "200ms",
                                                "data-wow-duration": "1500ms",
                                                children: (0, i.jsxs)("div", {
                                                    className: "auction-card",
                                                    children: [(0, i.jsxs)("div", {
                                                        className: "auction-card-img-wrap",
                                                        children: [(0, i.jsx)(r.default, {
                                                            href: "/auction/details",
                                                            className: "card-img",
                                                            children: (0, i.jsx)("img", {
                                                                src: "assets/img/inner-page/auction-img9.jpg",
                                                                alt: ""
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "batch",
                                                            children: (0, i.jsx)("span", {
                                                                children: "Live"
                                                            })
                                                        }), (0, i.jsx)("a", {
                                                            href: "#",
                                                            className: "wishlist",
                                                            children: (0, i.jsx)("svg", {
                                                                width: 16,
                                                                height: 15,
                                                                viewBox: "0 0 16 15",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                children: (0, i.jsx)("path", {
                                                                    d: "M8.00013 3.32629L7.32792 2.63535C5.75006 1.01348 2.85685 1.57317 1.81244 3.61222C1.32211 4.57128 1.21149 5.95597 2.10683 7.72315C2.96935 9.42471 4.76378 11.4628 8.00013 13.6828C11.2365 11.4628 13.03 9.42471 13.8934 7.72315C14.7888 5.95503 14.6791 4.57128 14.1878 3.61222C13.1434 1.57317 10.2502 1.01254 8.67234 2.63441L8.00013 3.32629ZM8.00013 14.8125C-6.375 5.31378 3.57406 -2.09995 7.83512 1.8216C7.89138 1.87317 7.94669 1.9266 8.00013 1.98192C8.05303 1.92665 8.10807 1.87349 8.16513 1.82254C12.4253 -2.10182 22.3753 5.31284 8.00013 14.8125Z"
                                                                })
                                                            })
                                                        }), (0, i.jsx)("div", {
                                                            className: "countdown-timer",
                                                            children: (0, i.jsxs)("ul", {
                                                                "data-countdown": "2025-10-23 12:00:00",
                                                                children: [(0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-days": 0,
                                                                    children: [a, "D"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-hours": 0,
                                                                    children: [o, "H"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-minutes": 0,
                                                                    children: [j, "M"]
                                                                }), (0, i.jsx)("li", {
                                                                    className: "colon",
                                                                    children: ":"
                                                                }), (0, i.jsxs)("li", {
                                                                    className: "times",
                                                                    "data-seconds": 0,
                                                                    children: [m, "Sec"]
                                                                })]
                                                            })
                                                        })]
                                                    }), (0, i.jsxs)("div", {
                                                        className: "auction-card-content",
                                                        children: [(0, i.jsx)("h6", {
                                                            children: (0, i.jsx)(r.default, {
                                                                href: "/auction/details",
                                                                children: "Where imagination meets the canvas"
                                                            })
                                                        }), (0, i.jsxs)("ul", {
                                                            children: [(0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Artist : "
                                                                }), "Frida Kahlo"]
                                                            }), (0, i.jsxs)("li", {
                                                                children: [(0, i.jsx)("span", {
                                                                    children: "Current Bidding : "
                                                                }), "$200.00"]
                                                            })]
                                                        }), (0, i.jsxs)(r.default, {
                                                            href: "/article/details",
                                                            className: "bid-btn btn-hover",
                                                            children: [(0, i.jsx)("span", {
                                                                children: "Bidding Start"
                                                            }), (0, i.jsx)("strong", {
                                                                style: {
                                                                    top: "48px",
                                                                    left: "69.5px"
                                                                }
                                                            })]
                                                        })]
                                                    })]
                                                })
                                            })]
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "row wow animate fadeInUp",
                                        "data-wow-delay": "200ms",
                                        "data-wow-duration": "1500ms",
                                        children: (0, i.jsx)("div", {
                                            className: "col-lg-12",
                                            children: (0, i.jsxs)("div", {
                                                className: "page-navigation-area d-flex flex-wrap align-items-center justify-content-between",
                                                children: [(0, i.jsx)("div", {
                                                    className: "prev-next-btn",
                                                    children: (0, i.jsxs)("a", {
                                                        href: "#",
                                                        children: [(0, i.jsx)("svg", {
                                                            width: 7,
                                                            height: 14,
                                                            viewBox: "0 0 7 14",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: (0, i.jsx)("path", {
                                                                d: "M0 7.00008L7 0L2.54545 7.00008L7 14L0 7.00008Z"
                                                            })
                                                        }), "prev"]
                                                    })
                                                }), (0, i.jsxs)("ul", {
                                                    className: "pagination",
                                                    children: [(0, i.jsx)("li", {
                                                        className: "active",
                                                        children: (0, i.jsx)("a", {
                                                            href: "#",
                                                            children: "01"
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsx)("a", {
                                                            href: "#",
                                                            children: "02"
                                                        })
                                                    }), (0, i.jsx)("li", {
                                                        children: (0, i.jsx)("a", {
                                                            href: "#",
                                                            children: "03"
                                                        })
                                                    })]
                                                }), (0, i.jsx)("div", {
                                                    className: "prev-next-btn",
                                                    children: (0, i.jsxs)("a", {
                                                        href: "#",
                                                        children: ["next", (0, i.jsx)("svg", {
                                                            width: 7,
                                                            height: 14,
                                                            viewBox: "0 0 7 14",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: (0, i.jsx)("path", {
                                                                d: "M7 7.00008L0 0L4.45455 7.00008L0 14L7 7.00008Z"
                                                            })
                                                        })]
                                                    })
                                                })]
                                            })
                                        })
                                    })]
                                })]
                            })
                        })
                    }), (0, i.jsx)(l.Z, {})]
                })
            }
        }
    },
    function(s) {
        s.O(0, [2291, 8820, 1050, 2330, 2971, 7023, 1744], function() {
            return s(s.s = 8741)
        }), _N_E = s.O()
    }
]);